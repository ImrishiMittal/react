import StudentRegistrationForm from "./components/StudentRegistrationForm";
function App() {
  return (
    <div>
      <StudentRegistrationForm />
    </div>
  );
}

export default App;
