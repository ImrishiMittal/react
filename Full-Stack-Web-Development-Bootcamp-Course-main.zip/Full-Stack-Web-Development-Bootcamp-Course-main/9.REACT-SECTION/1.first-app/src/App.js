//Tradintionally===html page but in react===Component
const App = () => {
  return <h1>This is my frist react app</h1>;
};

export default App;
