console.log("This is another method");
