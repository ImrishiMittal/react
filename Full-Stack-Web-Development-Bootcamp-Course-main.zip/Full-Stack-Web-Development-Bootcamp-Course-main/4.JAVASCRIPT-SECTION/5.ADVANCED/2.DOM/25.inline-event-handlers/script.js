//-----Mouse Event-----
function clickHandler() {
  //console.log("Click event is called");
}

function dbClickHandler() {
  //console.log("dbClickHandler event is called");
}

function onMouseOverHandler() {
  //console.log("onMouseOverHandler event is called");
}

function onMouseOutHandler() {
  //console.log("onMouseOutHandler event is called");
}

//-----Keyboard Event-----
function onkeydownHandler() {
  //console.log("onkeydownHandler event is called");
}

function onkeyupHandler() {
  //console.log("onkeyupHandler event is called");
}

function onkeypressHandler() {
  console.log("onkeypressHandler event is called");
}

//-----Form Events-----
function onsubmitHandler() {
  // console.log("onsubmitHandler event is called");
}

function onfocusHandler() {
  console.log("onfocusHandler event is called");
}

function onblurHandler() {
  console.log("onblurHandler event is called");
}
