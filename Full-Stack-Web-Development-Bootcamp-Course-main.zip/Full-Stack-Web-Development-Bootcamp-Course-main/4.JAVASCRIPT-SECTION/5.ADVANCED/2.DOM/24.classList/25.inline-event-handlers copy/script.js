//------Mouse Events-----
function clickHandler() {
  console.log("Clicked");
}

function doubleClickHandler() {
  console.log(" Double Clicked");
}

function mouseOverHandler() {
  // console.log("mouse over is called");
}

function mouseOutHandler() {
  // console.log("mouse out is called");
}
//------Keyboard Events-----
function keyDownHandler() {
  console.log("keyDownHandler is called");
}

function keyPressHandler() {
  console.log("keyPressHandler is called");
}

function keyUpHandler() {
  console.log("keyUpHandler is called");
}
