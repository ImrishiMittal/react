//!---Define the variables---
let ageOfJohn = 25; //Number
let ageOfDoe = 30;
let userInput = "25"; //string
// using == (double equal to)
// console.log(ageOfJohn == userInput);

// using ===
// console.log(ageOfJohn === userInput);

// using !=
// console.log(ageOfJohn != ageOfDoe);

// using !==
// console.log(ageOfJohn !== userInput);

// using >
// console.log(ageOfJohn > ageOfDoe);

// using >=
// console.log(ageOfJohn >= ageOfDoe);

// using <
// console.log(ageOfJohn < ageOfDoe);

// using <=
console.log(ageOfJohn <= ageOfDoe);
