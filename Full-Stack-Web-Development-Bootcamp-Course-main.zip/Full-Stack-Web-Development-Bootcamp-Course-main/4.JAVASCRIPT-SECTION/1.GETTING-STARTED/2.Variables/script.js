//!----- Using `var`----

//Task: Storing a person's first name

// var firstName = "Emmanuel";
// console.log(firstName);

//!-----Using `let`----

//Task: Storing a person's first name

// let firstName = "Emmanuel";
// console.log(firstName);
//!-----Using `const`----

//Task: Storing a person's first name

const firstName = "Emmanuel";
console.log(firstName);
