//Basic Arithmetic Operations
let a = 5;
let b = 2;
//Addition
// const results = a + b;

//Subtraction
// const results = a - b;

//multiplication
// const results = a * b;

//division
// const results = a / b;

//Using Modulus to Find Remainder
// const results = a % b;
//Increment and Decrement

let number = 10;
// number++; //incrase by 1
number--; //decrease by 1
// console.log(number);

//Compound Assignment with Arithmetic Operators
let score = 5;

score -= 2; // score/ 2

console.log(score);
