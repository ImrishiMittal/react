//!----- Using `var`----
var myAge = 30; //declared
myAge = 20;
//Re-assign
// console.log(myAge);
//!-----Using `let`----
let myScore = 10;
//Re-assign
myScore = 50;
// console.log(myScore);
//!-----Using `const`----
const myGrade = "A";
//Re-assign
myGrade = "B";
console.log(myGrade);
