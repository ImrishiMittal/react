// External JavaScript with `async`
console.log("This is my first js code");
