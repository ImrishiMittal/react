const os = require("os");

// os.arch()
//console.log("CPU Architecture", os.arch());

//os.cpus()
//console.log("CPU info", os.cpus());

//os.endianness()
//console.log(os.endianness());

//os.freemem()
//console.log(os.freemem());

//os.homedir()
//console.log(os.homedir());

//os.hostname()
// console.log(os.hostname());

// os.loadavg()
//console.log(os.loadavg());

//os.networkInterfaces()
//console.log(os.networkInterfaces());

// os.platform()
//console.log(os.platform());

//os.release()
//console.log(os.release());

//os.totalmem()

console.log(os.totalmem());
