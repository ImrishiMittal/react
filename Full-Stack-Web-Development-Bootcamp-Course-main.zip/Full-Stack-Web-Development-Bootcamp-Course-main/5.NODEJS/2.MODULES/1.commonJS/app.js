// const { add, subtract } = require("./utills");
console.log("App started...");
// const { add, subtract } = utills;
// console.log(add(10, 5));
// console.log(subtract(10, 5));

// console.log(add(2, 6));
// console.log(subtract(2, 6));

const { sayBye, sayHi } = require("./utills");

console.log(sayHi("Emmanuel"));
console.log(sayBye("Agnes"));
